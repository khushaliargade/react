import React from "react";
import { Header } from "./componenets/header";
import { Footer } from "./componenets/footer";
import { Navbar } from './componenets/navbar';
//import { Calendar } from "react-calendar";
import "react-calendar/dist/Calendar.css"
import "./componenets/style.css"
import UserTable from "./componenets/usertable";
//import { Routes } from "react-router-dom";
export class Home extends React.Component {
    render() {
        return (
            <div>
                <div>
                    <Header />
                </div>     
            <div class="grid">
                    <div class="aside">
                        <Navbar />
                    </div>
                    <div class="content">
                        {/* <Calendar 
                        defaultView ="month"
                        showDoubleView
                        
                        />          */}
                        <h3>THIS IS HOME</h3>
                        <UserTable />
                    </div>
                    <Footer />
                </div>
            </div>
        )
    }
}
