import React, { Component } from 'react'
class Classc extends Component {
    render() {
        return <h1>{this.props.name}
        </h1>
    }
}
export default Classc 