import React from 'react'
import headerLogo from "../../assets/header.png"
export class Header extends React.Component {
    render() {
        return (
            <img src={headerLogo} alt="" />
        )
    }
}